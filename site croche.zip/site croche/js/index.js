const imgs = document.getElementById("img");
const img = document.querySelectorAll("#img img");

let idx = 0;

function carrossel() {
    idx++;

    if (idx > img.length - 1) {
        idx = 0;
    }

    imgs.style.transform = `translateX(${`-${idx * 500}`}px)`;
}


setInterval(carrossel, 1800);



var listatable = [
    { 
        img: "img/img5.jpg",
        descricao: "Tenis roxo",
        valor: "200,00"
    },
    {
        img: "img/img6.jpg", 
        descricao: "Bolsa",
        valor: "180,00"
    },
    {
        img: "img/img7.jpg", 
        descricao: "Camiseta azul",
        valor: "100,00"
    },
    {
        img: "img/img8.jpg", 
        descricao: "Calca verde militar",
        valor: "180,00"
    },
    {
        img: "img/img9.jpg", 
        descricao: "Macaquinho cinza",
        valor: "130,00"
    },
    {
        img: "img/img10.jpg",
        descricao: "Moletom",
        valor: "90,00"
    }

];


for (var i = 0; i < listatable.length; i++) {
    var table = `
        <div class="card-roupas">
            <div class="foto-roupa">
                <img src="${listatable[i].img}">
            </div>
            <div class="descricao">
                ${listatable[i].descricao}
            </div>
            <div class="valor">
                R$ ${listatable[i].valor}
            </div>
            <button class="botao-comprar" type="button">Comprar</button>
        </div>`;

    document.getElementById("listatable").innerHTML += table;
    
    
}
