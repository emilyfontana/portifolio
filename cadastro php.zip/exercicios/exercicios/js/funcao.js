
async function cadastrar() {

    var formulario = document.getElementById('form-login');
    var dados = new FormData(formulario);

    var req = await fetch("login.php", {
        method: "POST",
        body: dados
    });

    var resposta = await req.json();
    alert(resposta.mensagem);
}