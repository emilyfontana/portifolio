<?php

$reposta["mensagem"] = "";


    if (empty($_POST["name"]) && empty($_POST["email"]) && empty($_POST["telefone"]) &&
        empty($_POST["nacionalidade"]) && empty($_POST["estado"]) && empty($_POST["senha"]) &&
        empty($_POST["datadenascimento"]) && empty($_POST["bairro"]) && empty($_POST["endereço"]) &&
        empty($_POST["cpf"])) {
        
        $reposta["mensagem"] = "campos não preenchidos";
    } else {
        $reposta["mensagem"] = "Campos preenchidos";
    }


echo(json_encode($reposta));

?>
