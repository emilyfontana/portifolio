var listacard = [
    {
        img: "img/js.png",
        descricao: "Meu repertório em javascript se aplica em desenvolvimento de websites anteriores, atribuindo funções, utilizando template string e etc. Um desses exemplos é esse mesmo projeto, onde utilizei de noções de template string para construir cards de apresentação.",

    },
    {
        img: "img/html.png",
        descricao: "Utilizei as ferramentas HTML, CSS e Figma afim de programar sites, e assim, aplicando sua devida estilização para atender a imagem visual que o site deveria passar aos consumidores desse conteúdo. Um exemplo disso foi o projeto extensivo realizado no curso BCC, acerca da ONG Crazy Cat Gang, na qual, trabalhando em grupo, fui responsável por criar uma página capaz de lidar com a gestão de voluntário, de animais e suprimentos da ONG.",

    },
    {
        img: "img/py.png",
        descricao: "Possuo hablidade em programação python onde um dos meus projetos anteriores consistiu em aplicar as funções CRUD utilizando o python3x em conjunto com sqlalquemy e o banco de dados sqlite, iniciei meus estudos a partir do curso online CS50 de harvard e aprimorei meus conhecimentos na universidade PUCPR.",

    }
];

for (var i = 0; i < listacard.length; i++) {
    var card = `<div class="card">
                    <div class="card-todos">
                        <div class="card-img">
                            <img src="${listacard[i].img}"  id="img-${i}">
                        </div>
                        <div class="card-descricao">
                            ${listacard[i].descricao}
                        </div>
                        <div class="botao">
                            <button class="saibamais" type="button"> Saiba mais </button>
                        </div>
                    </div>
                </div>`;
    document.getElementById("listacard").innerHTML += card;
}
